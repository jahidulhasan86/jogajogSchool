export const environment = {
    production: true,
    vchubAPI_EndPoint: "https://api.jogajog.com.bd/vsb/api/v1",
    api2_end_point: "",
    api3_end_point: ""
  };