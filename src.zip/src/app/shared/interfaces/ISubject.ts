export interface ISubject {
    subjects: object[],
    list_name: string,
    selected_subject: any
}