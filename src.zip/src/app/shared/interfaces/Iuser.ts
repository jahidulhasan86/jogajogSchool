export interface Iuser {
    users: object[],
    currentUrl: string
}
