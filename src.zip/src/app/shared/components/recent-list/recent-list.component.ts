import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ISubject } from '../../interfaces/ISubject';
import { XmppChatService } from '../../services/xmpp-chat/xmpp-chat.service';
import { online_status_xmpp } from '../../../../environments/environment'

@Component({
  selector: 'app-recent-list',
  templateUrl: './recent-list.component.html',
  styleUrls: ['./recent-list.component.css']
})
export class RecentListComponent implements OnInit {

  @Input() subjectObj: ISubject

  @Output() SubjectEvtEmitter = new EventEmitter<any>();

  selected_user_id: any;

  list_name: string

  subjectFilter: any = { subject_name: '' };

  chatsHistory: any[];

  constructor(private xmppChatService: XmppChatService) { }

  ngOnInit(): void {
    this.ShowHistory()
  }

  ngAfterViewInit() {
    // setTimeout(() => {
    //   if (this.subjectObj.subjects.length > 0) {
    //     this.subjectSelectedForChat()
    //   }
    // }, 500);
  }

  selectedSubject(subject) {
    // this.selected_user_id = subject.id
    // this.SubjectEvtEmitter.emit(subject)
  }

  subjectSelectedForChat() {
    // this.subjectObj.subjects.forEach((subject: any) => {
    //   if(subject.id === this.subjectObj.selected_subject.id){
    //     this.selectedSubject(subject)
    //   }
    // })
  }

  ShowHistory() {
    this.chatsHistory = []
    var chatRetrive = [];
    var chat = this.xmppChatService.latestMessage;
    for (var key in chat) {
      if (chat.hasOwnProperty(key)) {
        var statusobj = this.xmppChatService.presenceList[key.split("@")[0]];
        chat[key].onlinestatus = statusobj;
        if (statusobj == 'online' || statusobj == online_status_xmpp.online) {
        chat[key].inOnline = true;
        }
        chatRetrive.push(chat[key]);
      }
    }

    chatRetrive.sort(function (x, y) {
      return y.stamp - x.stamp;
    });

    this.chatsHistory = chatRetrive.sort((a, b) => (a.is_pinned === b.is_pinned) ? 0 : a.is_pinned ? -1 : 1);
    console.log("chat history:", this.chatsHistory)
  }

}
